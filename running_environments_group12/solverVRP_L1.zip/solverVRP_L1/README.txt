This is the same jar file on the website:
to run the program is only necessary to write into files.txt the desired instances ad execute the run.bat (Windows) or the run.sh (Unix).

Fabio Ferrero
S231779
Leader Workgroup 12